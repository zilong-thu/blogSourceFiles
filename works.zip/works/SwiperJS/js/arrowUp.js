var arrowUp = (function($){
    var _obj = {};

    var $arrowUp = $('.slide-arrow-wrapper');

    _obj.show = function(bool){
        var isHide = $arrowUp.hasClass('hide');
        if (bool) {
            $arrowUp.removeClass('hide');
        }else if(!bool && !isHide){
            $arrowUp.addClass('hide');
            console.log( $arrowUp.attr('class') );
        }
    };

    return _obj;
})(Zepto);