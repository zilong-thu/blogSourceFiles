(function( $ ) {
    /* 
     * viewAnimation在父元素上调用
     * 启动该父元素下的所有动画
     */
    $.fn.viewAnimation = function() {
        var $children = this.find('*[data-animation]');
 
        $children.each(function(index, element) {
            var $ele = $(element);
            var animation = $ele.data('animation');  // 动画名
            var delay = $ele.data('delay');  // 延迟时间

            var animationClassName = 'am-animation-' + animation;

            if (delay) {
                setTimeout(function(){
                    $ele.removeClass('animation-init').addClass(animationClassName);
                }, delay);
            }else{
                $ele.removeClass('animation-init').addClass(animationClassName);
            }
        });
 
        return this;
 
    };

    /*
     * 清除当前jquery对象下所有的元素动画（恢复到初始状态）
     * 这样，在下一次显示该slide时，动画再一次播放 
     */
    $.fn.clearAnimation = function(){
        var $children = this.find('*[data-animation]');
 
        $children.each(function(index, element) {
            var $ele = $(element);
            var animation = $ele.data('animation');  // 动画名
            
            var animationClassName = 'am-animation-' + animation;

            $ele.addClass('animation-init').removeClass(animationClassName);
        });
        return this;
    };
 
}( Zepto ));